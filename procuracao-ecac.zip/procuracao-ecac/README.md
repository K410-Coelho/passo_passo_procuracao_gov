# 📋 Procuração e-CAC — Guia Passo a Passo

Manual operacional visual para cadastro de Procuração Eletrônica no Portal e-CAC da Receita Federal.

🔗 **Acesse o guia publicado:** `https://<seu-usuario>.github.io/<nome-do-repositorio>/`

---

## 📁 Estrutura do Repositório

```
procuracao-ecac/
├── index.html          ← Página principal do guia
├── images/             ← Capturas de tela do processo
│   ├── _manu__-_Procuracao_Ecac_-_Imagem1.png
│   ├── _manu__-_Procuracao_Ecac_-_Imagem2.png
│   ├── _manu__-_Procuracao_Ecac_-_Imagem3.png
│   └── _manu__-_Procuracao_Ecac_-_Imagem4.png
└── README.md           ← Este arquivo
```

---

## 🚀 Como publicar no GitHub Pages

### Passo 1 — Crie o repositório

1. Acesse [github.com](https://github.com) e faça login
2. Clique em **"New repository"** (botão verde no canto superior direito)
3. Preencha:
   - **Repository name:** `procuracao-ecac` (ou o nome que preferir)
   - **Visibility:** Public ✅ *(necessário para GitHub Pages gratuito)*
4. Clique em **"Create repository"**

---

### Passo 2 — Faça o upload dos arquivos

#### Opção A — Pelo navegador (sem instalar nada)

1. No repositório criado, clique em **"uploading an existing file"**
2. Arraste todos os arquivos desta pasta para a área de upload:
   - `index.html`
   - A pasta `images/` com as 4 imagens dentro
3. No campo de commit, escreva: `Adiciona guia de Procuração e-CAC`
4. Clique em **"Commit changes"**

#### Opção B — Pelo terminal (Git)

```bash
git clone https://github.com/<seu-usuario>/<nome-do-repositorio>.git
cd <nome-do-repositorio>

# Copie os arquivos para esta pasta, depois:
git add .
git commit -m "Adiciona guia de Procuração e-CAC"
git push origin main
```

---

### Passo 3 — Ative o GitHub Pages

1. No repositório, clique em **"Settings"** (aba no menu superior)
2. No menu lateral esquerdo, clique em **"Pages"**
3. Em **"Branch"**, selecione `main` e pasta `/ (root)`
4. Clique em **"Save"**
5. Aguarde 1–2 minutos e acesse a URL gerada:
   ```
   https://<seu-usuario>.github.io/<nome-do-repositorio>/
   ```

---

## ✏️ Como atualizar o conteúdo

| O que mudar | Como fazer |
|---|---|
| Texto de um passo | Edite `index.html` diretamente no GitHub (clique no arquivo → ícone de lápis ✏️) |
| Trocar uma imagem | Faça upload da nova imagem na pasta `images/` com o mesmo nome |
| Mudar o número do WhatsApp | No `index.html`, busque `wa.me/5519999101673` e substitua pelo novo número |
| Mudar o CPF do contador | No `index.html`, busque `454.456.508-12` e edite |

---

## 📞 Contato

WhatsApp: [(19) 99910-1673](https://wa.me/5519999101673)
